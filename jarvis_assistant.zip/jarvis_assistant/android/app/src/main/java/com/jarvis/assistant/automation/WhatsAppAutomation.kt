package com.jarvis.assistant.automation

import android.content.Context

class WhatsAppAutomation(private val context: Context) {
    fun sendMessage(contact: String, message: String) {
        // Requires accessibility service
    }
}
