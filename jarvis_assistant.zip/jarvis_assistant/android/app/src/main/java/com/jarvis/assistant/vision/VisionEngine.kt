package com.jarvis.assistant.vision

import android.content.Context

class VisionEngine(private val context: Context) {
    fun detectObjects(imageData: ByteArray): List<String> {
        // ML Kit integration point
        return emptyList()
    }
}
