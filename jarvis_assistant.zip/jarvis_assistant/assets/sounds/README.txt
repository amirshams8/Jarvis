Add your sound effects here (optional)
Files: boot.wav, voice_start.wav, voice_end.wav